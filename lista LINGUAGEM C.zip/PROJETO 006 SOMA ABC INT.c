#include <stdio.h>
#include <stdlib.h>

int main () {

    int a, b, c, s;
    printf (" Digite o valor de A: ");
    scanf ("%d", &a);
    printf (" Digite o valor de B: ");
    scanf ("%d", &b);
    printf (" Digite o valor de C: ");
    scanf ("%d", &c);
    s = a+b+c;
    printf (" O valor de S e: %d", s);

    return 0;
}
