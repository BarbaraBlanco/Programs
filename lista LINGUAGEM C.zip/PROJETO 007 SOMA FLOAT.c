#include <stdio.h>
#include <stdlib.h>

float main () {

    float a, b, c, d, s;
    printf (" Digite o valor de A: ");
    scanf ("%f", &a);
    printf (" Digite o valor de B: ");
    scanf ("%f", &b);
    printf (" Digite o valor de C: ");
    scanf ("%f", &c);
    printf (" Digite o valor de D: ");
    scanf ("%f", &d);
    s = a+b+c+d;
    printf (" O valor de S e: %f", s);

    return 0;
}
