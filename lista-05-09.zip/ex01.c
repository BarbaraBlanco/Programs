#include <stdio.h>
#include "soma-ex01.h"

int main()
{
    int op = 0;
    while (op!=5){
        system("cls");
        printf("\ 1-Soma\ 2-Subtracao\ 3-Multiplicacao\ 4-Divisao\ 5-Sair: ");
        scanf("%d",&op);
        if (op==1){
            soma();

        }
        if (op==2){
            subtracao();

        }
        if (op==3){
            multiplicacao();
        }
        if (op==4){
            divisao();
        }
        if (op==5){
            printf("\nPressione um tecla para finalizar.");
            getch();
            break;
        }

        printf("\nPressione um tecla para continuar...");
        getch();
    }

    return 0;
}


