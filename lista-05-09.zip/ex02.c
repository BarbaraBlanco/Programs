#include <stdio.h>
#include "primos-ex02.h"

int main(){
    int op = 0;
    while(op!=2)
    {
        system("cls");
        int num;
        printf("\nDigite um numero: ");
        scanf("%d", &num);
        primo(num);
        printf("\nDigite 1-Continuar, 2-Encerrar: ");
        scanf("%d", &op);
        if(op==1){
        printf("\nDigite um numero: ");
        scanf("%d", &num);
        primo(num);
        }
        if(op==2){
        printf("\nPressione um tecla para finalizar.");
        getch();
        break;
        }
        printf("\nPressione um tecla para continuar...");
        getch();


    }
return 0;}
