#include <stdio.h>
#include "temperatura-ex03.h"


int main() {
    float t;
    char op;

    printf("Digite 'F' para Fahrenheit, 'C' para Celsius: ");
    scanf(" %c", &op);

    printf("Digite uma temperatura que deseja converter: ");
    scanf("%f", &t);

    if (op == 'F') {
        float resultadoC = fahrenheitParaCelsius(t);
        printf("A conversao de Fahrenheit para Celsius eh: %.2f\n", resultadoC);
    } else if (op == 'C') {
        float resultadoF = celsiusParaFahrenheit(t);
        printf("A conversao de Celsius para Fahrenheit eh: %.2f\n", resultadoF);
    } else {
        printf("Opcao invalida.\n");
    }

    return 0;
}
