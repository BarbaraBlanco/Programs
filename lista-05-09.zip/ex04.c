#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "numeroaleatorio-ex04.h"

int main() {
    srand(time(NULL));

    const int numeroMinimo = 1;
    const int numeroMaximo = 100;
    int numeroAleatorio = gerarNumeroAleatorio(numeroMinimo, numeroMaximo);
    int palpite;
    int tentativas = 0;

    printf("Bem vindo ao jogo de adivinhacao!\n");
    printf("Tente adivinhar o numero entre %d e %d.\n", numeroMinimo, numeroMaximo);

    do {
        palpite = receberPalpite();
        tentativas++;

        if (palpite < numeroAleatorio) {
            printf("Tente um numero maior.\n");
        } else if (palpite > numeroAleatorio) {
            printf("Tente um numero menor.\n");
        } else {
            printf("Parabens, voce acertou em %d tentativas!\n", tentativas);
        }
    } while (palpite != numeroAleatorio);

    return 0;
}
