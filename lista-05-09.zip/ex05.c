#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "vogaleconsoante-ex05.h"

int main() {
    char frase[255];
    int resultados[2] = {0, 0};

    printf("Digite uma frase: ");
    fgets(frase, sizeof(frase), stdin);

    vogaleconsoante(frase, resultados);

    printf("Qnt vogais: %d\n", resultados[0]);
    printf("Qnt consoantes: %d\n", resultados[1]);

    return 0;
}
