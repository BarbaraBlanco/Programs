#include <stdio.h>

int main() {
    int a;
    char b;
    float c;

    printf("Digite um numero inteiro: ");
    scanf("%d", &a);

    printf("Digite uma letra: ");
    scanf(" %c", &b);

    printf("Digite um numero real: ");
    scanf("%f", &c);

    int *pInt = &a;
    char *pChar = &b;
    float *pFloat = &c;

    int tempInt = *pInt;
    *pInt = *pChar;
    *pChar = *pFloat;
    *pFloat = tempInt;

    printf("\nValor do inteiro: %d", a);
    printf("\nValor do char: %c", b);
    printf("\nValor do float: %.2f", c);

    return 0;
}
