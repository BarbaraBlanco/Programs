#include <stdio.h>

int main() {
    int num1, num2;

    printf("Digite o primeiro numero inteiro: ");
    scanf("%d", &num1);

    printf("Digite o segundo numero inteiro: ");
    scanf("%d", &num2);

    int *ptr1 = &num1;
    int *ptr2 = &num2;
    if (*ptr1 > *ptr2) {
        printf("O maior numero eh: %d\n", *ptr1);
    } else if (*ptr2 > *ptr1) {
        printf("O maior numero eh: %d\n", *ptr2);
    } else {
        printf("Os numeros sao iguais: %d e %d\n", *ptr1, *ptr2);
    }

    return 0;}
