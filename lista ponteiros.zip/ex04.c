#include <stdio.h>

int main(){
    int a=1; int b=0;
    int *pA = &a;
    int *pB = &b;
    printf("\nO valor de A (antes da troca de valores: %d\n", *pA);
    printf("\nO valor de B (antes da troca de valores: %d\n", *pB);

    int temp = *pA;
    *pA = *pB;
    *pB = temp;


    printf("\nO valor de A (depois da troca de valores: %d\n",*pA);
    printf("\nO valor de B (depois da troca de valores: %d\n",*pB);


return 0;}
