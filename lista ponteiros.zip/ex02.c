#include <stdio.h>

int main(){

int num0;
int num1;
    printf("\nDigite um numero inteiro: ");
    scanf("%d", &num0);
    printf("\nDigite outro numero inteiro: ");
    scanf("%d", &num1);
    int *pt = &num0;
    int *pr = &num1;

    if(*pt > *pr){
        printf("\nO maior numero eh: %d\n", *pt);
    }if (*pr > *pt){
        printf("\nO maior numero eh: %d\n", *pr);
    }if(*pr == *pt){
        printf("\nOs numeros sao iguais: %d e %d\n", *pt, *pr);
    }

return 0;}
