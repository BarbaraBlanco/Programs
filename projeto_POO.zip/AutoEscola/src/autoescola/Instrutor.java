/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autoescola;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author gasin
 */
@Entity
@Table(name = "instrutor")
@NamedQueries({
    @NamedQuery(name = "Instrutor.findAll", query = "SELECT i FROM Instrutor i"),
    @NamedQuery(name = "Instrutor.findByIdInstrutor", query = "SELECT i FROM Instrutor i WHERE i.idInstrutor = :idInstrutor"),
    @NamedQuery(name = "Instrutor.findByEmailInstrutor", query = "SELECT i FROM Instrutor i WHERE i.emailInstrutor = :emailInstrutor"),
    @NamedQuery(name = "Instrutor.findByPnomeInstrutor", query = "SELECT i FROM Instrutor i WHERE i.pnomeInstrutor = :pnomeInstrutor"),
    @NamedQuery(name = "Instrutor.findBySnomeInstrutor", query = "SELECT i FROM Instrutor i WHERE i.snomeInstrutor = :snomeInstrutor"),
    @NamedQuery(name = "Instrutor.findBySenha", query = "SELECT i FROM Instrutor i WHERE i.senha = :senha")})
public class Instrutor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_instrutor")
    private Integer idInstrutor;
    @Basic(optional = false)
    @Column(name = "email_instrutor")
    private String emailInstrutor;
    @Basic(optional = false)
    @Column(name = "pnome_instrutor")
    private String pnomeInstrutor;
    @Basic(optional = false)
    @Column(name = "snome_instrutor")
    private String snomeInstrutor;
    @Basic(optional = false)
    @Column(name = "senha")
    private String senha;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "instrutorIdInstrutor")
    private List<AgendamentoAula> agendamentoAulaList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "instrutorIdInstrutor")
    private List<VerificacaoVeiculo> verificacaoVeiculoList;

    public Instrutor() {
    }

    public Instrutor(Integer idInstrutor) {
        this.idInstrutor = idInstrutor;
    }

    public Instrutor(String emailInstrutor, String pnomeInstrutor, String snomeInstrutor, String senha) {
        this.emailInstrutor = emailInstrutor;
        this.pnomeInstrutor = pnomeInstrutor;
        this.snomeInstrutor = snomeInstrutor;
        this.senha = senha;
    }

    public Integer getIdInstrutor() {
        return idInstrutor;
    }

    public void setIdInstrutor(Integer idInstrutor) {
        this.idInstrutor = idInstrutor;
    }

    public String getEmailInstrutor() {
        return emailInstrutor;
    }

    public void setEmailInstrutor(String emailInstrutor) {
        this.emailInstrutor = emailInstrutor;
    }

    public String getPnomeInstrutor() {
        return pnomeInstrutor;
    }

    public void setPnomeInstrutor(String pnomeInstrutor) {
        this.pnomeInstrutor = pnomeInstrutor;
    }

    public String getSnomeInstrutor() {
        return snomeInstrutor;
    }

    public void setSnomeInstrutor(String snomeInstrutor) {
        this.snomeInstrutor = snomeInstrutor;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public List<AgendamentoAula> getAgendamentoAulaList() {
        return agendamentoAulaList;
    }

    public void setAgendamentoAulaList(List<AgendamentoAula> agendamentoAulaList) {
        this.agendamentoAulaList = agendamentoAulaList;
    }

    public List<VerificacaoVeiculo> getVerificacaoVeiculoList() {
        return verificacaoVeiculoList;
    }

    public void setVerificacaoVeiculoList(List<VerificacaoVeiculo> verificacaoVeiculoList) {
        this.verificacaoVeiculoList = verificacaoVeiculoList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idInstrutor != null ? idInstrutor.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Instrutor)) {
            return false;
        }
        Instrutor other = (Instrutor) object;
        if ((this.idInstrutor == null && other.idInstrutor != null) || (this.idInstrutor != null && !this.idInstrutor.equals(other.idInstrutor))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "autoescola.Instrutor[ idInstrutor=" + idInstrutor + " ]";
    }
    
}
