/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autoescola.controllers;

import autoescola.AgendamentoAula;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import autoescola.Alunos;
import autoescola.Avaliacao;
import autoescola.Instrutor;
import autoescola.controlelers.exceptions.NonexistentEntityException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author gasin
 */
public class AgendamentoAulaJpaController implements Serializable {

    public AgendamentoAulaJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(AgendamentoAula agendamentoAula) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Alunos alunosIdAluno = agendamentoAula.getAlunosIdAluno();
            if (alunosIdAluno != null) {
                alunosIdAluno = em.getReference(alunosIdAluno.getClass(), alunosIdAluno.getIdAluno());
                agendamentoAula.setAlunosIdAluno(alunosIdAluno);
            }
            Avaliacao avaliacaoIdAvaliacao = agendamentoAula.getAvaliacaoIdAvaliacao();
            if (avaliacaoIdAvaliacao != null) {
                avaliacaoIdAvaliacao = em.getReference(avaliacaoIdAvaliacao.getClass(), avaliacaoIdAvaliacao.getIdAvaliacao());
                agendamentoAula.setAvaliacaoIdAvaliacao(avaliacaoIdAvaliacao);
            }
            Instrutor instrutorIdInstrutor = agendamentoAula.getInstrutorIdInstrutor();
            if (instrutorIdInstrutor != null) {
                instrutorIdInstrutor = em.getReference(instrutorIdInstrutor.getClass(), instrutorIdInstrutor.getIdInstrutor());
                agendamentoAula.setInstrutorIdInstrutor(instrutorIdInstrutor);
            }
            em.persist(agendamentoAula);
            if (alunosIdAluno != null) {
                alunosIdAluno.getAgendamentoAulaList().add(agendamentoAula);
                alunosIdAluno = em.merge(alunosIdAluno);
            }
            if (avaliacaoIdAvaliacao != null) {
                avaliacaoIdAvaliacao.getAgendamentoAulaList().add(agendamentoAula);
                avaliacaoIdAvaliacao = em.merge(avaliacaoIdAvaliacao);
            }
            if (instrutorIdInstrutor != null) {
                instrutorIdInstrutor.getAgendamentoAulaList().add(agendamentoAula);
                instrutorIdInstrutor = em.merge(instrutorIdInstrutor);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(AgendamentoAula agendamentoAula) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            AgendamentoAula persistentAgendamentoAula = em.find(AgendamentoAula.class, agendamentoAula.getIdAgendamento());
            Alunos alunosIdAlunoOld = persistentAgendamentoAula.getAlunosIdAluno();
            Alunos alunosIdAlunoNew = agendamentoAula.getAlunosIdAluno();
            Avaliacao avaliacaoIdAvaliacaoOld = persistentAgendamentoAula.getAvaliacaoIdAvaliacao();
            Avaliacao avaliacaoIdAvaliacaoNew = agendamentoAula.getAvaliacaoIdAvaliacao();
            Instrutor instrutorIdInstrutorOld = persistentAgendamentoAula.getInstrutorIdInstrutor();
            Instrutor instrutorIdInstrutorNew = agendamentoAula.getInstrutorIdInstrutor();
            if (alunosIdAlunoNew != null) {
                alunosIdAlunoNew = em.getReference(alunosIdAlunoNew.getClass(), alunosIdAlunoNew.getIdAluno());
                agendamentoAula.setAlunosIdAluno(alunosIdAlunoNew);
            }
            if (avaliacaoIdAvaliacaoNew != null) {
                avaliacaoIdAvaliacaoNew = em.getReference(avaliacaoIdAvaliacaoNew.getClass(), avaliacaoIdAvaliacaoNew.getIdAvaliacao());
                agendamentoAula.setAvaliacaoIdAvaliacao(avaliacaoIdAvaliacaoNew);
            }
            if (instrutorIdInstrutorNew != null) {
                instrutorIdInstrutorNew = em.getReference(instrutorIdInstrutorNew.getClass(), instrutorIdInstrutorNew.getIdInstrutor());
                agendamentoAula.setInstrutorIdInstrutor(instrutorIdInstrutorNew);
            }
            agendamentoAula = em.merge(agendamentoAula);
            if (alunosIdAlunoOld != null && !alunosIdAlunoOld.equals(alunosIdAlunoNew)) {
                alunosIdAlunoOld.getAgendamentoAulaList().remove(agendamentoAula);
                alunosIdAlunoOld = em.merge(alunosIdAlunoOld);
            }
            if (alunosIdAlunoNew != null && !alunosIdAlunoNew.equals(alunosIdAlunoOld)) {
                alunosIdAlunoNew.getAgendamentoAulaList().add(agendamentoAula);
                alunosIdAlunoNew = em.merge(alunosIdAlunoNew);
            }
            if (avaliacaoIdAvaliacaoOld != null && !avaliacaoIdAvaliacaoOld.equals(avaliacaoIdAvaliacaoNew)) {
                avaliacaoIdAvaliacaoOld.getAgendamentoAulaList().remove(agendamentoAula);
                avaliacaoIdAvaliacaoOld = em.merge(avaliacaoIdAvaliacaoOld);
            }
            if (avaliacaoIdAvaliacaoNew != null && !avaliacaoIdAvaliacaoNew.equals(avaliacaoIdAvaliacaoOld)) {
                avaliacaoIdAvaliacaoNew.getAgendamentoAulaList().add(agendamentoAula);
                avaliacaoIdAvaliacaoNew = em.merge(avaliacaoIdAvaliacaoNew);
            }
            if (instrutorIdInstrutorOld != null && !instrutorIdInstrutorOld.equals(instrutorIdInstrutorNew)) {
                instrutorIdInstrutorOld.getAgendamentoAulaList().remove(agendamentoAula);
                instrutorIdInstrutorOld = em.merge(instrutorIdInstrutorOld);
            }
            if (instrutorIdInstrutorNew != null && !instrutorIdInstrutorNew.equals(instrutorIdInstrutorOld)) {
                instrutorIdInstrutorNew.getAgendamentoAulaList().add(agendamentoAula);
                instrutorIdInstrutorNew = em.merge(instrutorIdInstrutorNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = agendamentoAula.getIdAgendamento();
                if (findAgendamentoAula(id) == null) {
                    throw new NonexistentEntityException("The agendamentoAula with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            AgendamentoAula agendamentoAula;
            try {
                agendamentoAula = em.getReference(AgendamentoAula.class, id);
                agendamentoAula.getIdAgendamento();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The agendamentoAula with id " + id + " no longer exists.", enfe);
            }
            Alunos alunosIdAluno = agendamentoAula.getAlunosIdAluno();
            if (alunosIdAluno != null) {
                alunosIdAluno.getAgendamentoAulaList().remove(agendamentoAula);
                alunosIdAluno = em.merge(alunosIdAluno);
            }
            Avaliacao avaliacaoIdAvaliacao = agendamentoAula.getAvaliacaoIdAvaliacao();
            if (avaliacaoIdAvaliacao != null) {
                avaliacaoIdAvaliacao.getAgendamentoAulaList().remove(agendamentoAula);
                avaliacaoIdAvaliacao = em.merge(avaliacaoIdAvaliacao);
            }
            Instrutor instrutorIdInstrutor = agendamentoAula.getInstrutorIdInstrutor();
            if (instrutorIdInstrutor != null) {
                instrutorIdInstrutor.getAgendamentoAulaList().remove(agendamentoAula);
                instrutorIdInstrutor = em.merge(instrutorIdInstrutor);
            }
            em.remove(agendamentoAula);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<AgendamentoAula> findAgendamentoAulaEntities() {
        return findAgendamentoAulaEntities(true, -1, -1);
    }

    public List<AgendamentoAula> findAgendamentoAulaEntities(int maxResults, int firstResult) {
        return findAgendamentoAulaEntities(false, maxResults, firstResult);
    }

    private List<AgendamentoAula> findAgendamentoAulaEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(AgendamentoAula.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public AgendamentoAula findAgendamentoAula(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(AgendamentoAula.class, id);
        } finally {
            em.close();
        }
    }

    public int getAgendamentoAulaCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<AgendamentoAula> rt = cq.from(AgendamentoAula.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
