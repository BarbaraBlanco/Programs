/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autoescola.controllers;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import autoescola.AgendamentoAula;
import autoescola.Avaliacao;
import autoescola.controlelers.exceptions.IllegalOrphanException;
import autoescola.controlelers.exceptions.NonexistentEntityException;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author gasin
 */
public class AvaliacaoJpaController implements Serializable {

    public AvaliacaoJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Avaliacao avaliacao) {
        if (avaliacao.getAgendamentoAulaList() == null) {
            avaliacao.setAgendamentoAulaList(new ArrayList<AgendamentoAula>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            List<AgendamentoAula> attachedAgendamentoAulaList = new ArrayList<AgendamentoAula>();
            for (AgendamentoAula agendamentoAulaListAgendamentoAulaToAttach : avaliacao.getAgendamentoAulaList()) {
                agendamentoAulaListAgendamentoAulaToAttach = em.getReference(agendamentoAulaListAgendamentoAulaToAttach.getClass(), agendamentoAulaListAgendamentoAulaToAttach.getIdAgendamento());
                attachedAgendamentoAulaList.add(agendamentoAulaListAgendamentoAulaToAttach);
            }
            avaliacao.setAgendamentoAulaList(attachedAgendamentoAulaList);
            em.persist(avaliacao);
            for (AgendamentoAula agendamentoAulaListAgendamentoAula : avaliacao.getAgendamentoAulaList()) {
                Avaliacao oldAvaliacaoIdAvaliacaoOfAgendamentoAulaListAgendamentoAula = agendamentoAulaListAgendamentoAula.getAvaliacaoIdAvaliacao();
                agendamentoAulaListAgendamentoAula.setAvaliacaoIdAvaliacao(avaliacao);
                agendamentoAulaListAgendamentoAula = em.merge(agendamentoAulaListAgendamentoAula);
                if (oldAvaliacaoIdAvaliacaoOfAgendamentoAulaListAgendamentoAula != null) {
                    oldAvaliacaoIdAvaliacaoOfAgendamentoAulaListAgendamentoAula.getAgendamentoAulaList().remove(agendamentoAulaListAgendamentoAula);
                    oldAvaliacaoIdAvaliacaoOfAgendamentoAulaListAgendamentoAula = em.merge(oldAvaliacaoIdAvaliacaoOfAgendamentoAulaListAgendamentoAula);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Avaliacao avaliacao) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Avaliacao persistentAvaliacao = em.find(Avaliacao.class, avaliacao.getIdAvaliacao());
            List<AgendamentoAula> agendamentoAulaListOld = persistentAvaliacao.getAgendamentoAulaList();
            List<AgendamentoAula> agendamentoAulaListNew = avaliacao.getAgendamentoAulaList();
            List<String> illegalOrphanMessages = null;
            for (AgendamentoAula agendamentoAulaListOldAgendamentoAula : agendamentoAulaListOld) {
                if (!agendamentoAulaListNew.contains(agendamentoAulaListOldAgendamentoAula)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain AgendamentoAula " + agendamentoAulaListOldAgendamentoAula + " since its avaliacaoIdAvaliacao field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<AgendamentoAula> attachedAgendamentoAulaListNew = new ArrayList<AgendamentoAula>();
            for (AgendamentoAula agendamentoAulaListNewAgendamentoAulaToAttach : agendamentoAulaListNew) {
                agendamentoAulaListNewAgendamentoAulaToAttach = em.getReference(agendamentoAulaListNewAgendamentoAulaToAttach.getClass(), agendamentoAulaListNewAgendamentoAulaToAttach.getIdAgendamento());
                attachedAgendamentoAulaListNew.add(agendamentoAulaListNewAgendamentoAulaToAttach);
            }
            agendamentoAulaListNew = attachedAgendamentoAulaListNew;
            avaliacao.setAgendamentoAulaList(agendamentoAulaListNew);
            avaliacao = em.merge(avaliacao);
            for (AgendamentoAula agendamentoAulaListNewAgendamentoAula : agendamentoAulaListNew) {
                if (!agendamentoAulaListOld.contains(agendamentoAulaListNewAgendamentoAula)) {
                    Avaliacao oldAvaliacaoIdAvaliacaoOfAgendamentoAulaListNewAgendamentoAula = agendamentoAulaListNewAgendamentoAula.getAvaliacaoIdAvaliacao();
                    agendamentoAulaListNewAgendamentoAula.setAvaliacaoIdAvaliacao(avaliacao);
                    agendamentoAulaListNewAgendamentoAula = em.merge(agendamentoAulaListNewAgendamentoAula);
                    if (oldAvaliacaoIdAvaliacaoOfAgendamentoAulaListNewAgendamentoAula != null && !oldAvaliacaoIdAvaliacaoOfAgendamentoAulaListNewAgendamentoAula.equals(avaliacao)) {
                        oldAvaliacaoIdAvaliacaoOfAgendamentoAulaListNewAgendamentoAula.getAgendamentoAulaList().remove(agendamentoAulaListNewAgendamentoAula);
                        oldAvaliacaoIdAvaliacaoOfAgendamentoAulaListNewAgendamentoAula = em.merge(oldAvaliacaoIdAvaliacaoOfAgendamentoAulaListNewAgendamentoAula);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = avaliacao.getIdAvaliacao();
                if (findAvaliacao(id) == null) {
                    throw new NonexistentEntityException("The avaliacao with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Avaliacao avaliacao;
            try {
                avaliacao = em.getReference(Avaliacao.class, id);
                avaliacao.getIdAvaliacao();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The avaliacao with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<AgendamentoAula> agendamentoAulaListOrphanCheck = avaliacao.getAgendamentoAulaList();
            for (AgendamentoAula agendamentoAulaListOrphanCheckAgendamentoAula : agendamentoAulaListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Avaliacao (" + avaliacao + ") cannot be destroyed since the AgendamentoAula " + agendamentoAulaListOrphanCheckAgendamentoAula + " in its agendamentoAulaList field has a non-nullable avaliacaoIdAvaliacao field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(avaliacao);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Avaliacao> findAvaliacaoEntities() {
        return findAvaliacaoEntities(true, -1, -1);
    }

    public List<Avaliacao> findAvaliacaoEntities(int maxResults, int firstResult) {
        return findAvaliacaoEntities(false, maxResults, firstResult);
    }

    private List<Avaliacao> findAvaliacaoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Avaliacao.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Avaliacao findAvaliacao(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Avaliacao.class, id);
        } finally {
            em.close();
        }
    }

    public int getAvaliacaoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Avaliacao> rt = cq.from(Avaliacao.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
