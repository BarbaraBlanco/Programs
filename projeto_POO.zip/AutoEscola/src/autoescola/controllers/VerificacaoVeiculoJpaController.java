/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autoescola.controllers;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import autoescola.Instrutor;
import autoescola.Veiculo;
import autoescola.VerificacaoVeiculo;
import autoescola.controlelers.exceptions.NonexistentEntityException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author gasin
 */
public class VerificacaoVeiculoJpaController implements Serializable {

    public VerificacaoVeiculoJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(VerificacaoVeiculo verificacaoVeiculo) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Instrutor instrutorIdInstrutor = verificacaoVeiculo.getInstrutorIdInstrutor();
            if (instrutorIdInstrutor != null) {
                instrutorIdInstrutor = em.getReference(instrutorIdInstrutor.getClass(), instrutorIdInstrutor.getIdInstrutor());
                verificacaoVeiculo.setInstrutorIdInstrutor(instrutorIdInstrutor);
            }
            Veiculo veiculoIdVeiculo = verificacaoVeiculo.getVeiculoIdVeiculo();
            if (veiculoIdVeiculo != null) {
                veiculoIdVeiculo = em.getReference(veiculoIdVeiculo.getClass(), veiculoIdVeiculo.getIdVeiculo());
                verificacaoVeiculo.setVeiculoIdVeiculo(veiculoIdVeiculo);
            }
            em.persist(verificacaoVeiculo);
            if (instrutorIdInstrutor != null) {
                instrutorIdInstrutor.getVerificacaoVeiculoList().add(verificacaoVeiculo);
                instrutorIdInstrutor = em.merge(instrutorIdInstrutor);
            }
            if (veiculoIdVeiculo != null) {
                veiculoIdVeiculo.getVerificacaoVeiculoList().add(verificacaoVeiculo);
                veiculoIdVeiculo = em.merge(veiculoIdVeiculo);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(VerificacaoVeiculo verificacaoVeiculo) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            VerificacaoVeiculo persistentVerificacaoVeiculo = em.find(VerificacaoVeiculo.class, verificacaoVeiculo.getIdVerificacao());
            Instrutor instrutorIdInstrutorOld = persistentVerificacaoVeiculo.getInstrutorIdInstrutor();
            Instrutor instrutorIdInstrutorNew = verificacaoVeiculo.getInstrutorIdInstrutor();
            Veiculo veiculoIdVeiculoOld = persistentVerificacaoVeiculo.getVeiculoIdVeiculo();
            Veiculo veiculoIdVeiculoNew = verificacaoVeiculo.getVeiculoIdVeiculo();
            if (instrutorIdInstrutorNew != null) {
                instrutorIdInstrutorNew = em.getReference(instrutorIdInstrutorNew.getClass(), instrutorIdInstrutorNew.getIdInstrutor());
                verificacaoVeiculo.setInstrutorIdInstrutor(instrutorIdInstrutorNew);
            }
            if (veiculoIdVeiculoNew != null) {
                veiculoIdVeiculoNew = em.getReference(veiculoIdVeiculoNew.getClass(), veiculoIdVeiculoNew.getIdVeiculo());
                verificacaoVeiculo.setVeiculoIdVeiculo(veiculoIdVeiculoNew);
            }
            verificacaoVeiculo = em.merge(verificacaoVeiculo);
            if (instrutorIdInstrutorOld != null && !instrutorIdInstrutorOld.equals(instrutorIdInstrutorNew)) {
                instrutorIdInstrutorOld.getVerificacaoVeiculoList().remove(verificacaoVeiculo);
                instrutorIdInstrutorOld = em.merge(instrutorIdInstrutorOld);
            }
            if (instrutorIdInstrutorNew != null && !instrutorIdInstrutorNew.equals(instrutorIdInstrutorOld)) {
                instrutorIdInstrutorNew.getVerificacaoVeiculoList().add(verificacaoVeiculo);
                instrutorIdInstrutorNew = em.merge(instrutorIdInstrutorNew);
            }
            if (veiculoIdVeiculoOld != null && !veiculoIdVeiculoOld.equals(veiculoIdVeiculoNew)) {
                veiculoIdVeiculoOld.getVerificacaoVeiculoList().remove(verificacaoVeiculo);
                veiculoIdVeiculoOld = em.merge(veiculoIdVeiculoOld);
            }
            if (veiculoIdVeiculoNew != null && !veiculoIdVeiculoNew.equals(veiculoIdVeiculoOld)) {
                veiculoIdVeiculoNew.getVerificacaoVeiculoList().add(verificacaoVeiculo);
                veiculoIdVeiculoNew = em.merge(veiculoIdVeiculoNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = verificacaoVeiculo.getIdVerificacao();
                if (findVerificacaoVeiculo(id) == null) {
                    throw new NonexistentEntityException("The verificacaoVeiculo with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            VerificacaoVeiculo verificacaoVeiculo;
            try {
                verificacaoVeiculo = em.getReference(VerificacaoVeiculo.class, id);
                verificacaoVeiculo.getIdVerificacao();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The verificacaoVeiculo with id " + id + " no longer exists.", enfe);
            }
            Instrutor instrutorIdInstrutor = verificacaoVeiculo.getInstrutorIdInstrutor();
            if (instrutorIdInstrutor != null) {
                instrutorIdInstrutor.getVerificacaoVeiculoList().remove(verificacaoVeiculo);
                instrutorIdInstrutor = em.merge(instrutorIdInstrutor);
            }
            Veiculo veiculoIdVeiculo = verificacaoVeiculo.getVeiculoIdVeiculo();
            if (veiculoIdVeiculo != null) {
                veiculoIdVeiculo.getVerificacaoVeiculoList().remove(verificacaoVeiculo);
                veiculoIdVeiculo = em.merge(veiculoIdVeiculo);
            }
            em.remove(verificacaoVeiculo);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<VerificacaoVeiculo> findVerificacaoVeiculoEntities() {
        return findVerificacaoVeiculoEntities(true, -1, -1);
    }

    public List<VerificacaoVeiculo> findVerificacaoVeiculoEntities(int maxResults, int firstResult) {
        return findVerificacaoVeiculoEntities(false, maxResults, firstResult);
    }

    private List<VerificacaoVeiculo> findVerificacaoVeiculoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(VerificacaoVeiculo.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public VerificacaoVeiculo findVerificacaoVeiculo(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(VerificacaoVeiculo.class, id);
        } finally {
            em.close();
        }
    }

    public int getVerificacaoVeiculoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<VerificacaoVeiculo> rt = cq.from(VerificacaoVeiculo.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
