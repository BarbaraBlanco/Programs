/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autoescola.controllers;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import autoescola.AgendamentoAula;
import autoescola.Alunos;
import java.util.ArrayList;
import java.util.List;
import autoescola.Exame;
import autoescola.Cnh;
import autoescola.controlelers.exceptions.IllegalOrphanException;
import autoescola.controlelers.exceptions.NonexistentEntityException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author gasin
 */
public class AlunosJpaController implements Serializable {

    public AlunosJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Alunos alunos) {
        if (alunos.getAgendamentoAulaList() == null) {
            alunos.setAgendamentoAulaList(new ArrayList<AgendamentoAula>());
        }
        if (alunos.getExameList() == null) {
            alunos.setExameList(new ArrayList<Exame>());
        }
        if (alunos.getCnhList() == null) {
            alunos.setCnhList(new ArrayList<Cnh>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            List<AgendamentoAula> attachedAgendamentoAulaList = new ArrayList<AgendamentoAula>();
            for (AgendamentoAula agendamentoAulaListAgendamentoAulaToAttach : alunos.getAgendamentoAulaList()) {
                agendamentoAulaListAgendamentoAulaToAttach = em.getReference(agendamentoAulaListAgendamentoAulaToAttach.getClass(), agendamentoAulaListAgendamentoAulaToAttach.getIdAgendamento());
                attachedAgendamentoAulaList.add(agendamentoAulaListAgendamentoAulaToAttach);
            }
            alunos.setAgendamentoAulaList(attachedAgendamentoAulaList);
            List<Exame> attachedExameList = new ArrayList<Exame>();
            for (Exame exameListExameToAttach : alunos.getExameList()) {
                exameListExameToAttach = em.getReference(exameListExameToAttach.getClass(), exameListExameToAttach.getIdExame());
                attachedExameList.add(exameListExameToAttach);
            }
            alunos.setExameList(attachedExameList);
            List<Cnh> attachedCnhList = new ArrayList<Cnh>();
            for (Cnh cnhListCnhToAttach : alunos.getCnhList()) {
                cnhListCnhToAttach = em.getReference(cnhListCnhToAttach.getClass(), cnhListCnhToAttach.getIdCnh());
                attachedCnhList.add(cnhListCnhToAttach);
            }
            alunos.setCnhList(attachedCnhList);
            em.persist(alunos);
            for (AgendamentoAula agendamentoAulaListAgendamentoAula : alunos.getAgendamentoAulaList()) {
                Alunos oldAlunosIdAlunoOfAgendamentoAulaListAgendamentoAula = agendamentoAulaListAgendamentoAula.getAlunosIdAluno();
                agendamentoAulaListAgendamentoAula.setAlunosIdAluno(alunos);
                agendamentoAulaListAgendamentoAula = em.merge(agendamentoAulaListAgendamentoAula);
                if (oldAlunosIdAlunoOfAgendamentoAulaListAgendamentoAula != null) {
                    oldAlunosIdAlunoOfAgendamentoAulaListAgendamentoAula.getAgendamentoAulaList().remove(agendamentoAulaListAgendamentoAula);
                    oldAlunosIdAlunoOfAgendamentoAulaListAgendamentoAula = em.merge(oldAlunosIdAlunoOfAgendamentoAulaListAgendamentoAula);
                }
            }
            for (Exame exameListExame : alunos.getExameList()) {
                Alunos oldAlunosIdAlunoOfExameListExame = exameListExame.getAlunosIdAluno();
                exameListExame.setAlunosIdAluno(alunos);
                exameListExame = em.merge(exameListExame);
                if (oldAlunosIdAlunoOfExameListExame != null) {
                    oldAlunosIdAlunoOfExameListExame.getExameList().remove(exameListExame);
                    oldAlunosIdAlunoOfExameListExame = em.merge(oldAlunosIdAlunoOfExameListExame);
                }
            }
            for (Cnh cnhListCnh : alunos.getCnhList()) {
                Alunos oldAlunosIdAlunoOfCnhListCnh = cnhListCnh.getAlunosIdAluno();
                cnhListCnh.setAlunosIdAluno(alunos);
                cnhListCnh = em.merge(cnhListCnh);
                if (oldAlunosIdAlunoOfCnhListCnh != null) {
                    oldAlunosIdAlunoOfCnhListCnh.getCnhList().remove(cnhListCnh);
                    oldAlunosIdAlunoOfCnhListCnh = em.merge(oldAlunosIdAlunoOfCnhListCnh);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Alunos alunos) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Alunos persistentAlunos = em.find(Alunos.class, alunos.getIdAluno());
            List<AgendamentoAula> agendamentoAulaListOld = persistentAlunos.getAgendamentoAulaList();
            List<AgendamentoAula> agendamentoAulaListNew = alunos.getAgendamentoAulaList();
            List<Exame> exameListOld = persistentAlunos.getExameList();
            List<Exame> exameListNew = alunos.getExameList();
            List<Cnh> cnhListOld = persistentAlunos.getCnhList();
            List<Cnh> cnhListNew = alunos.getCnhList();
            List<String> illegalOrphanMessages = null;
            for (AgendamentoAula agendamentoAulaListOldAgendamentoAula : agendamentoAulaListOld) {
                if (!agendamentoAulaListNew.contains(agendamentoAulaListOldAgendamentoAula)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain AgendamentoAula " + agendamentoAulaListOldAgendamentoAula + " since its alunosIdAluno field is not nullable.");
                }
            }
            for (Exame exameListOldExame : exameListOld) {
                if (!exameListNew.contains(exameListOldExame)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Exame " + exameListOldExame + " since its alunosIdAluno field is not nullable.");
                }
            }
            for (Cnh cnhListOldCnh : cnhListOld) {
                if (!cnhListNew.contains(cnhListOldCnh)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Cnh " + cnhListOldCnh + " since its alunosIdAluno field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<AgendamentoAula> attachedAgendamentoAulaListNew = new ArrayList<AgendamentoAula>();
            for (AgendamentoAula agendamentoAulaListNewAgendamentoAulaToAttach : agendamentoAulaListNew) {
                agendamentoAulaListNewAgendamentoAulaToAttach = em.getReference(agendamentoAulaListNewAgendamentoAulaToAttach.getClass(), agendamentoAulaListNewAgendamentoAulaToAttach.getIdAgendamento());
                attachedAgendamentoAulaListNew.add(agendamentoAulaListNewAgendamentoAulaToAttach);
            }
            agendamentoAulaListNew = attachedAgendamentoAulaListNew;
            alunos.setAgendamentoAulaList(agendamentoAulaListNew);
            List<Exame> attachedExameListNew = new ArrayList<Exame>();
            for (Exame exameListNewExameToAttach : exameListNew) {
                exameListNewExameToAttach = em.getReference(exameListNewExameToAttach.getClass(), exameListNewExameToAttach.getIdExame());
                attachedExameListNew.add(exameListNewExameToAttach);
            }
            exameListNew = attachedExameListNew;
            alunos.setExameList(exameListNew);
            List<Cnh> attachedCnhListNew = new ArrayList<Cnh>();
            for (Cnh cnhListNewCnhToAttach : cnhListNew) {
                cnhListNewCnhToAttach = em.getReference(cnhListNewCnhToAttach.getClass(), cnhListNewCnhToAttach.getIdCnh());
                attachedCnhListNew.add(cnhListNewCnhToAttach);
            }
            cnhListNew = attachedCnhListNew;
            alunos.setCnhList(cnhListNew);
            alunos = em.merge(alunos);
            for (AgendamentoAula agendamentoAulaListNewAgendamentoAula : agendamentoAulaListNew) {
                if (!agendamentoAulaListOld.contains(agendamentoAulaListNewAgendamentoAula)) {
                    Alunos oldAlunosIdAlunoOfAgendamentoAulaListNewAgendamentoAula = agendamentoAulaListNewAgendamentoAula.getAlunosIdAluno();
                    agendamentoAulaListNewAgendamentoAula.setAlunosIdAluno(alunos);
                    agendamentoAulaListNewAgendamentoAula = em.merge(agendamentoAulaListNewAgendamentoAula);
                    if (oldAlunosIdAlunoOfAgendamentoAulaListNewAgendamentoAula != null && !oldAlunosIdAlunoOfAgendamentoAulaListNewAgendamentoAula.equals(alunos)) {
                        oldAlunosIdAlunoOfAgendamentoAulaListNewAgendamentoAula.getAgendamentoAulaList().remove(agendamentoAulaListNewAgendamentoAula);
                        oldAlunosIdAlunoOfAgendamentoAulaListNewAgendamentoAula = em.merge(oldAlunosIdAlunoOfAgendamentoAulaListNewAgendamentoAula);
                    }
                }
            }
            for (Exame exameListNewExame : exameListNew) {
                if (!exameListOld.contains(exameListNewExame)) {
                    Alunos oldAlunosIdAlunoOfExameListNewExame = exameListNewExame.getAlunosIdAluno();
                    exameListNewExame.setAlunosIdAluno(alunos);
                    exameListNewExame = em.merge(exameListNewExame);
                    if (oldAlunosIdAlunoOfExameListNewExame != null && !oldAlunosIdAlunoOfExameListNewExame.equals(alunos)) {
                        oldAlunosIdAlunoOfExameListNewExame.getExameList().remove(exameListNewExame);
                        oldAlunosIdAlunoOfExameListNewExame = em.merge(oldAlunosIdAlunoOfExameListNewExame);
                    }
                }
            }
            for (Cnh cnhListNewCnh : cnhListNew) {
                if (!cnhListOld.contains(cnhListNewCnh)) {
                    Alunos oldAlunosIdAlunoOfCnhListNewCnh = cnhListNewCnh.getAlunosIdAluno();
                    cnhListNewCnh.setAlunosIdAluno(alunos);
                    cnhListNewCnh = em.merge(cnhListNewCnh);
                    if (oldAlunosIdAlunoOfCnhListNewCnh != null && !oldAlunosIdAlunoOfCnhListNewCnh.equals(alunos)) {
                        oldAlunosIdAlunoOfCnhListNewCnh.getCnhList().remove(cnhListNewCnh);
                        oldAlunosIdAlunoOfCnhListNewCnh = em.merge(oldAlunosIdAlunoOfCnhListNewCnh);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = alunos.getIdAluno();
                if (findAlunos(id) == null) {
                    throw new NonexistentEntityException("The alunos with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Alunos alunos;
            try {
                alunos = em.getReference(Alunos.class, id);
                alunos.getIdAluno();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The alunos with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<AgendamentoAula> agendamentoAulaListOrphanCheck = alunos.getAgendamentoAulaList();
            for (AgendamentoAula agendamentoAulaListOrphanCheckAgendamentoAula : agendamentoAulaListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Alunos (" + alunos + ") cannot be destroyed since the AgendamentoAula " + agendamentoAulaListOrphanCheckAgendamentoAula + " in its agendamentoAulaList field has a non-nullable alunosIdAluno field.");
            }
            List<Exame> exameListOrphanCheck = alunos.getExameList();
            for (Exame exameListOrphanCheckExame : exameListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Alunos (" + alunos + ") cannot be destroyed since the Exame " + exameListOrphanCheckExame + " in its exameList field has a non-nullable alunosIdAluno field.");
            }
            List<Cnh> cnhListOrphanCheck = alunos.getCnhList();
            for (Cnh cnhListOrphanCheckCnh : cnhListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Alunos (" + alunos + ") cannot be destroyed since the Cnh " + cnhListOrphanCheckCnh + " in its cnhList field has a non-nullable alunosIdAluno field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(alunos);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Alunos> findAlunosEntities() {
        return findAlunosEntities(true, -1, -1);
    }

    public List<Alunos> findAlunosEntities(int maxResults, int firstResult) {
        return findAlunosEntities(false, maxResults, firstResult);
    }

    private List<Alunos> findAlunosEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Alunos.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Alunos findAlunos(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Alunos.class, id);
        } finally {
            em.close();
        }
    }

    public int getAlunosCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Alunos> rt = cq.from(Alunos.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
