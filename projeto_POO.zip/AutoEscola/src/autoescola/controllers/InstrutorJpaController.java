/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autoescola.controllers;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import autoescola.AgendamentoAula;
import autoescola.Instrutor;
import java.util.ArrayList;
import java.util.List;
import autoescola.VerificacaoVeiculo;
import autoescola.controlelers.exceptions.IllegalOrphanException;
import autoescola.controlelers.exceptions.NonexistentEntityException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author gasin
 */
public class InstrutorJpaController implements Serializable {

    public InstrutorJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Instrutor instrutor) {
        if (instrutor.getAgendamentoAulaList() == null) {
            instrutor.setAgendamentoAulaList(new ArrayList<AgendamentoAula>());
        }
        if (instrutor.getVerificacaoVeiculoList() == null) {
            instrutor.setVerificacaoVeiculoList(new ArrayList<VerificacaoVeiculo>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            List<AgendamentoAula> attachedAgendamentoAulaList = new ArrayList<AgendamentoAula>();
            for (AgendamentoAula agendamentoAulaListAgendamentoAulaToAttach : instrutor.getAgendamentoAulaList()) {
                agendamentoAulaListAgendamentoAulaToAttach = em.getReference(agendamentoAulaListAgendamentoAulaToAttach.getClass(), agendamentoAulaListAgendamentoAulaToAttach.getIdAgendamento());
                attachedAgendamentoAulaList.add(agendamentoAulaListAgendamentoAulaToAttach);
            }
            instrutor.setAgendamentoAulaList(attachedAgendamentoAulaList);
            List<VerificacaoVeiculo> attachedVerificacaoVeiculoList = new ArrayList<VerificacaoVeiculo>();
            for (VerificacaoVeiculo verificacaoVeiculoListVerificacaoVeiculoToAttach : instrutor.getVerificacaoVeiculoList()) {
                verificacaoVeiculoListVerificacaoVeiculoToAttach = em.getReference(verificacaoVeiculoListVerificacaoVeiculoToAttach.getClass(), verificacaoVeiculoListVerificacaoVeiculoToAttach.getIdVerificacao());
                attachedVerificacaoVeiculoList.add(verificacaoVeiculoListVerificacaoVeiculoToAttach);
            }
            instrutor.setVerificacaoVeiculoList(attachedVerificacaoVeiculoList);
            em.persist(instrutor);
            for (AgendamentoAula agendamentoAulaListAgendamentoAula : instrutor.getAgendamentoAulaList()) {
                Instrutor oldInstrutorIdInstrutorOfAgendamentoAulaListAgendamentoAula = agendamentoAulaListAgendamentoAula.getInstrutorIdInstrutor();
                agendamentoAulaListAgendamentoAula.setInstrutorIdInstrutor(instrutor);
                agendamentoAulaListAgendamentoAula = em.merge(agendamentoAulaListAgendamentoAula);
                if (oldInstrutorIdInstrutorOfAgendamentoAulaListAgendamentoAula != null) {
                    oldInstrutorIdInstrutorOfAgendamentoAulaListAgendamentoAula.getAgendamentoAulaList().remove(agendamentoAulaListAgendamentoAula);
                    oldInstrutorIdInstrutorOfAgendamentoAulaListAgendamentoAula = em.merge(oldInstrutorIdInstrutorOfAgendamentoAulaListAgendamentoAula);
                }
            }
            for (VerificacaoVeiculo verificacaoVeiculoListVerificacaoVeiculo : instrutor.getVerificacaoVeiculoList()) {
                Instrutor oldInstrutorIdInstrutorOfVerificacaoVeiculoListVerificacaoVeiculo = verificacaoVeiculoListVerificacaoVeiculo.getInstrutorIdInstrutor();
                verificacaoVeiculoListVerificacaoVeiculo.setInstrutorIdInstrutor(instrutor);
                verificacaoVeiculoListVerificacaoVeiculo = em.merge(verificacaoVeiculoListVerificacaoVeiculo);
                if (oldInstrutorIdInstrutorOfVerificacaoVeiculoListVerificacaoVeiculo != null) {
                    oldInstrutorIdInstrutorOfVerificacaoVeiculoListVerificacaoVeiculo.getVerificacaoVeiculoList().remove(verificacaoVeiculoListVerificacaoVeiculo);
                    oldInstrutorIdInstrutorOfVerificacaoVeiculoListVerificacaoVeiculo = em.merge(oldInstrutorIdInstrutorOfVerificacaoVeiculoListVerificacaoVeiculo);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Instrutor instrutor) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Instrutor persistentInstrutor = em.find(Instrutor.class, instrutor.getIdInstrutor());
            List<AgendamentoAula> agendamentoAulaListOld = persistentInstrutor.getAgendamentoAulaList();
            List<AgendamentoAula> agendamentoAulaListNew = instrutor.getAgendamentoAulaList();
            List<VerificacaoVeiculo> verificacaoVeiculoListOld = persistentInstrutor.getVerificacaoVeiculoList();
            List<VerificacaoVeiculo> verificacaoVeiculoListNew = instrutor.getVerificacaoVeiculoList();
            List<String> illegalOrphanMessages = null;
            for (AgendamentoAula agendamentoAulaListOldAgendamentoAula : agendamentoAulaListOld) {
                if (!agendamentoAulaListNew.contains(agendamentoAulaListOldAgendamentoAula)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain AgendamentoAula " + agendamentoAulaListOldAgendamentoAula + " since its instrutorIdInstrutor field is not nullable.");
                }
            }
            for (VerificacaoVeiculo verificacaoVeiculoListOldVerificacaoVeiculo : verificacaoVeiculoListOld) {
                if (!verificacaoVeiculoListNew.contains(verificacaoVeiculoListOldVerificacaoVeiculo)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain VerificacaoVeiculo " + verificacaoVeiculoListOldVerificacaoVeiculo + " since its instrutorIdInstrutor field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<AgendamentoAula> attachedAgendamentoAulaListNew = new ArrayList<AgendamentoAula>();
            for (AgendamentoAula agendamentoAulaListNewAgendamentoAulaToAttach : agendamentoAulaListNew) {
                agendamentoAulaListNewAgendamentoAulaToAttach = em.getReference(agendamentoAulaListNewAgendamentoAulaToAttach.getClass(), agendamentoAulaListNewAgendamentoAulaToAttach.getIdAgendamento());
                attachedAgendamentoAulaListNew.add(agendamentoAulaListNewAgendamentoAulaToAttach);
            }
            agendamentoAulaListNew = attachedAgendamentoAulaListNew;
            instrutor.setAgendamentoAulaList(agendamentoAulaListNew);
            List<VerificacaoVeiculo> attachedVerificacaoVeiculoListNew = new ArrayList<VerificacaoVeiculo>();
            for (VerificacaoVeiculo verificacaoVeiculoListNewVerificacaoVeiculoToAttach : verificacaoVeiculoListNew) {
                verificacaoVeiculoListNewVerificacaoVeiculoToAttach = em.getReference(verificacaoVeiculoListNewVerificacaoVeiculoToAttach.getClass(), verificacaoVeiculoListNewVerificacaoVeiculoToAttach.getIdVerificacao());
                attachedVerificacaoVeiculoListNew.add(verificacaoVeiculoListNewVerificacaoVeiculoToAttach);
            }
            verificacaoVeiculoListNew = attachedVerificacaoVeiculoListNew;
            instrutor.setVerificacaoVeiculoList(verificacaoVeiculoListNew);
            instrutor = em.merge(instrutor);
            for (AgendamentoAula agendamentoAulaListNewAgendamentoAula : agendamentoAulaListNew) {
                if (!agendamentoAulaListOld.contains(agendamentoAulaListNewAgendamentoAula)) {
                    Instrutor oldInstrutorIdInstrutorOfAgendamentoAulaListNewAgendamentoAula = agendamentoAulaListNewAgendamentoAula.getInstrutorIdInstrutor();
                    agendamentoAulaListNewAgendamentoAula.setInstrutorIdInstrutor(instrutor);
                    agendamentoAulaListNewAgendamentoAula = em.merge(agendamentoAulaListNewAgendamentoAula);
                    if (oldInstrutorIdInstrutorOfAgendamentoAulaListNewAgendamentoAula != null && !oldInstrutorIdInstrutorOfAgendamentoAulaListNewAgendamentoAula.equals(instrutor)) {
                        oldInstrutorIdInstrutorOfAgendamentoAulaListNewAgendamentoAula.getAgendamentoAulaList().remove(agendamentoAulaListNewAgendamentoAula);
                        oldInstrutorIdInstrutorOfAgendamentoAulaListNewAgendamentoAula = em.merge(oldInstrutorIdInstrutorOfAgendamentoAulaListNewAgendamentoAula);
                    }
                }
            }
            for (VerificacaoVeiculo verificacaoVeiculoListNewVerificacaoVeiculo : verificacaoVeiculoListNew) {
                if (!verificacaoVeiculoListOld.contains(verificacaoVeiculoListNewVerificacaoVeiculo)) {
                    Instrutor oldInstrutorIdInstrutorOfVerificacaoVeiculoListNewVerificacaoVeiculo = verificacaoVeiculoListNewVerificacaoVeiculo.getInstrutorIdInstrutor();
                    verificacaoVeiculoListNewVerificacaoVeiculo.setInstrutorIdInstrutor(instrutor);
                    verificacaoVeiculoListNewVerificacaoVeiculo = em.merge(verificacaoVeiculoListNewVerificacaoVeiculo);
                    if (oldInstrutorIdInstrutorOfVerificacaoVeiculoListNewVerificacaoVeiculo != null && !oldInstrutorIdInstrutorOfVerificacaoVeiculoListNewVerificacaoVeiculo.equals(instrutor)) {
                        oldInstrutorIdInstrutorOfVerificacaoVeiculoListNewVerificacaoVeiculo.getVerificacaoVeiculoList().remove(verificacaoVeiculoListNewVerificacaoVeiculo);
                        oldInstrutorIdInstrutorOfVerificacaoVeiculoListNewVerificacaoVeiculo = em.merge(oldInstrutorIdInstrutorOfVerificacaoVeiculoListNewVerificacaoVeiculo);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = instrutor.getIdInstrutor();
                if (findInstrutor(id) == null) {
                    throw new NonexistentEntityException("The instrutor with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Instrutor instrutor;
            try {
                instrutor = em.getReference(Instrutor.class, id);
                instrutor.getIdInstrutor();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The instrutor with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<AgendamentoAula> agendamentoAulaListOrphanCheck = instrutor.getAgendamentoAulaList();
            for (AgendamentoAula agendamentoAulaListOrphanCheckAgendamentoAula : agendamentoAulaListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Instrutor (" + instrutor + ") cannot be destroyed since the AgendamentoAula " + agendamentoAulaListOrphanCheckAgendamentoAula + " in its agendamentoAulaList field has a non-nullable instrutorIdInstrutor field.");
            }
            List<VerificacaoVeiculo> verificacaoVeiculoListOrphanCheck = instrutor.getVerificacaoVeiculoList();
            for (VerificacaoVeiculo verificacaoVeiculoListOrphanCheckVerificacaoVeiculo : verificacaoVeiculoListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Instrutor (" + instrutor + ") cannot be destroyed since the VerificacaoVeiculo " + verificacaoVeiculoListOrphanCheckVerificacaoVeiculo + " in its verificacaoVeiculoList field has a non-nullable instrutorIdInstrutor field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(instrutor);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Instrutor> findInstrutorEntities() {
        return findInstrutorEntities(true, -1, -1);
    }

    public List<Instrutor> findInstrutorEntities(int maxResults, int firstResult) {
        return findInstrutorEntities(false, maxResults, firstResult);
    }

    private List<Instrutor> findInstrutorEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Instrutor.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Instrutor findInstrutor(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Instrutor.class, id);
        } finally {
            em.close();
        }
    }

    public int getInstrutorCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Instrutor> rt = cq.from(Instrutor.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
