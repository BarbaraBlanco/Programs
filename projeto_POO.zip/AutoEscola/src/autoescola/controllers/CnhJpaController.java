/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autoescola.controllers;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import autoescola.Alunos;
import autoescola.Cnh;
import autoescola.controlelers.exceptions.NonexistentEntityException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author gasin
 */
public class CnhJpaController implements Serializable {

    public CnhJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Cnh cnh) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Alunos alunosIdAluno = cnh.getAlunosIdAluno();
            if (alunosIdAluno != null) {
                alunosIdAluno = em.getReference(alunosIdAluno.getClass(), alunosIdAluno.getIdAluno());
                cnh.setAlunosIdAluno(alunosIdAluno);
            }
            em.persist(cnh);
            if (alunosIdAluno != null) {
                alunosIdAluno.getCnhList().add(cnh);
                alunosIdAluno = em.merge(alunosIdAluno);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Cnh cnh) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cnh persistentCnh = em.find(Cnh.class, cnh.getIdCnh());
            Alunos alunosIdAlunoOld = persistentCnh.getAlunosIdAluno();
            Alunos alunosIdAlunoNew = cnh.getAlunosIdAluno();
            if (alunosIdAlunoNew != null) {
                alunosIdAlunoNew = em.getReference(alunosIdAlunoNew.getClass(), alunosIdAlunoNew.getIdAluno());
                cnh.setAlunosIdAluno(alunosIdAlunoNew);
            }
            cnh = em.merge(cnh);
            if (alunosIdAlunoOld != null && !alunosIdAlunoOld.equals(alunosIdAlunoNew)) {
                alunosIdAlunoOld.getCnhList().remove(cnh);
                alunosIdAlunoOld = em.merge(alunosIdAlunoOld);
            }
            if (alunosIdAlunoNew != null && !alunosIdAlunoNew.equals(alunosIdAlunoOld)) {
                alunosIdAlunoNew.getCnhList().add(cnh);
                alunosIdAlunoNew = em.merge(alunosIdAlunoNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = cnh.getIdCnh();
                if (findCnh(id) == null) {
                    throw new NonexistentEntityException("The cnh with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cnh cnh;
            try {
                cnh = em.getReference(Cnh.class, id);
                cnh.getIdCnh();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The cnh with id " + id + " no longer exists.", enfe);
            }
            Alunos alunosIdAluno = cnh.getAlunosIdAluno();
            if (alunosIdAluno != null) {
                alunosIdAluno.getCnhList().remove(cnh);
                alunosIdAluno = em.merge(alunosIdAluno);
            }
            em.remove(cnh);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Cnh> findCnhEntities() {
        return findCnhEntities(true, -1, -1);
    }

    public List<Cnh> findCnhEntities(int maxResults, int firstResult) {
        return findCnhEntities(false, maxResults, firstResult);
    }

    private List<Cnh> findCnhEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Cnh.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Cnh findCnh(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Cnh.class, id);
        } finally {
            em.close();
        }
    }

    public int getCnhCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Cnh> rt = cq.from(Cnh.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
