/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autoescola.controllers;

import autoescola.Veiculo;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import autoescola.VerificacaoVeiculo;
import autoescola.controlelers.exceptions.IllegalOrphanException;
import autoescola.controlelers.exceptions.NonexistentEntityException;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author gasin
 */
public class VeiculoJpaController implements Serializable {

    public VeiculoJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Veiculo veiculo) {
        if (veiculo.getVerificacaoVeiculoList() == null) {
            veiculo.setVerificacaoVeiculoList(new ArrayList<VerificacaoVeiculo>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            List<VerificacaoVeiculo> attachedVerificacaoVeiculoList = new ArrayList<VerificacaoVeiculo>();
            for (VerificacaoVeiculo verificacaoVeiculoListVerificacaoVeiculoToAttach : veiculo.getVerificacaoVeiculoList()) {
                verificacaoVeiculoListVerificacaoVeiculoToAttach = em.getReference(verificacaoVeiculoListVerificacaoVeiculoToAttach.getClass(), verificacaoVeiculoListVerificacaoVeiculoToAttach.getIdVerificacao());
                attachedVerificacaoVeiculoList.add(verificacaoVeiculoListVerificacaoVeiculoToAttach);
            }
            veiculo.setVerificacaoVeiculoList(attachedVerificacaoVeiculoList);
            em.persist(veiculo);
            for (VerificacaoVeiculo verificacaoVeiculoListVerificacaoVeiculo : veiculo.getVerificacaoVeiculoList()) {
                Veiculo oldVeiculoIdVeiculoOfVerificacaoVeiculoListVerificacaoVeiculo = verificacaoVeiculoListVerificacaoVeiculo.getVeiculoIdVeiculo();
                verificacaoVeiculoListVerificacaoVeiculo.setVeiculoIdVeiculo(veiculo);
                verificacaoVeiculoListVerificacaoVeiculo = em.merge(verificacaoVeiculoListVerificacaoVeiculo);
                if (oldVeiculoIdVeiculoOfVerificacaoVeiculoListVerificacaoVeiculo != null) {
                    oldVeiculoIdVeiculoOfVerificacaoVeiculoListVerificacaoVeiculo.getVerificacaoVeiculoList().remove(verificacaoVeiculoListVerificacaoVeiculo);
                    oldVeiculoIdVeiculoOfVerificacaoVeiculoListVerificacaoVeiculo = em.merge(oldVeiculoIdVeiculoOfVerificacaoVeiculoListVerificacaoVeiculo);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Veiculo veiculo) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Veiculo persistentVeiculo = em.find(Veiculo.class, veiculo.getIdVeiculo());
            List<VerificacaoVeiculo> verificacaoVeiculoListOld = persistentVeiculo.getVerificacaoVeiculoList();
            List<VerificacaoVeiculo> verificacaoVeiculoListNew = veiculo.getVerificacaoVeiculoList();
            List<String> illegalOrphanMessages = null;
            for (VerificacaoVeiculo verificacaoVeiculoListOldVerificacaoVeiculo : verificacaoVeiculoListOld) {
                if (!verificacaoVeiculoListNew.contains(verificacaoVeiculoListOldVerificacaoVeiculo)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain VerificacaoVeiculo " + verificacaoVeiculoListOldVerificacaoVeiculo + " since its veiculoIdVeiculo field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<VerificacaoVeiculo> attachedVerificacaoVeiculoListNew = new ArrayList<VerificacaoVeiculo>();
            for (VerificacaoVeiculo verificacaoVeiculoListNewVerificacaoVeiculoToAttach : verificacaoVeiculoListNew) {
                verificacaoVeiculoListNewVerificacaoVeiculoToAttach = em.getReference(verificacaoVeiculoListNewVerificacaoVeiculoToAttach.getClass(), verificacaoVeiculoListNewVerificacaoVeiculoToAttach.getIdVerificacao());
                attachedVerificacaoVeiculoListNew.add(verificacaoVeiculoListNewVerificacaoVeiculoToAttach);
            }
            verificacaoVeiculoListNew = attachedVerificacaoVeiculoListNew;
            veiculo.setVerificacaoVeiculoList(verificacaoVeiculoListNew);
            veiculo = em.merge(veiculo);
            for (VerificacaoVeiculo verificacaoVeiculoListNewVerificacaoVeiculo : verificacaoVeiculoListNew) {
                if (!verificacaoVeiculoListOld.contains(verificacaoVeiculoListNewVerificacaoVeiculo)) {
                    Veiculo oldVeiculoIdVeiculoOfVerificacaoVeiculoListNewVerificacaoVeiculo = verificacaoVeiculoListNewVerificacaoVeiculo.getVeiculoIdVeiculo();
                    verificacaoVeiculoListNewVerificacaoVeiculo.setVeiculoIdVeiculo(veiculo);
                    verificacaoVeiculoListNewVerificacaoVeiculo = em.merge(verificacaoVeiculoListNewVerificacaoVeiculo);
                    if (oldVeiculoIdVeiculoOfVerificacaoVeiculoListNewVerificacaoVeiculo != null && !oldVeiculoIdVeiculoOfVerificacaoVeiculoListNewVerificacaoVeiculo.equals(veiculo)) {
                        oldVeiculoIdVeiculoOfVerificacaoVeiculoListNewVerificacaoVeiculo.getVerificacaoVeiculoList().remove(verificacaoVeiculoListNewVerificacaoVeiculo);
                        oldVeiculoIdVeiculoOfVerificacaoVeiculoListNewVerificacaoVeiculo = em.merge(oldVeiculoIdVeiculoOfVerificacaoVeiculoListNewVerificacaoVeiculo);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = veiculo.getIdVeiculo();
                if (findVeiculo(id) == null) {
                    throw new NonexistentEntityException("The veiculo with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Veiculo veiculo;
            try {
                veiculo = em.getReference(Veiculo.class, id);
                veiculo.getIdVeiculo();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The veiculo with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<VerificacaoVeiculo> verificacaoVeiculoListOrphanCheck = veiculo.getVerificacaoVeiculoList();
            for (VerificacaoVeiculo verificacaoVeiculoListOrphanCheckVerificacaoVeiculo : verificacaoVeiculoListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Veiculo (" + veiculo + ") cannot be destroyed since the VerificacaoVeiculo " + verificacaoVeiculoListOrphanCheckVerificacaoVeiculo + " in its verificacaoVeiculoList field has a non-nullable veiculoIdVeiculo field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(veiculo);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Veiculo> findVeiculoEntities() {
        return findVeiculoEntities(true, -1, -1);
    }

    public List<Veiculo> findVeiculoEntities(int maxResults, int firstResult) {
        return findVeiculoEntities(false, maxResults, firstResult);
    }

    private List<Veiculo> findVeiculoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Veiculo.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Veiculo findVeiculo(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Veiculo.class, id);
        } finally {
            em.close();
        }
    }

    public int getVeiculoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Veiculo> rt = cq.from(Veiculo.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
