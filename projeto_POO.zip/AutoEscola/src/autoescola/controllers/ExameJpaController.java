/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autoescola.controllers;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import autoescola.Alunos;
import autoescola.Exame;
import autoescola.controlelers.exceptions.NonexistentEntityException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author gasin
 */
public class ExameJpaController implements Serializable {

    public ExameJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Exame exame) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Alunos alunosIdAluno = exame.getAlunosIdAluno();
            if (alunosIdAluno != null) {
                alunosIdAluno = em.getReference(alunosIdAluno.getClass(), alunosIdAluno.getIdAluno());
                exame.setAlunosIdAluno(alunosIdAluno);
            }
            em.persist(exame);
            if (alunosIdAluno != null) {
                alunosIdAluno.getExameList().add(exame);
                alunosIdAluno = em.merge(alunosIdAluno);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Exame exame) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Exame persistentExame = em.find(Exame.class, exame.getIdExame());
            Alunos alunosIdAlunoOld = persistentExame.getAlunosIdAluno();
            Alunos alunosIdAlunoNew = exame.getAlunosIdAluno();
            if (alunosIdAlunoNew != null) {
                alunosIdAlunoNew = em.getReference(alunosIdAlunoNew.getClass(), alunosIdAlunoNew.getIdAluno());
                exame.setAlunosIdAluno(alunosIdAlunoNew);
            }
            exame = em.merge(exame);
            if (alunosIdAlunoOld != null && !alunosIdAlunoOld.equals(alunosIdAlunoNew)) {
                alunosIdAlunoOld.getExameList().remove(exame);
                alunosIdAlunoOld = em.merge(alunosIdAlunoOld);
            }
            if (alunosIdAlunoNew != null && !alunosIdAlunoNew.equals(alunosIdAlunoOld)) {
                alunosIdAlunoNew.getExameList().add(exame);
                alunosIdAlunoNew = em.merge(alunosIdAlunoNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = exame.getIdExame();
                if (findExame(id) == null) {
                    throw new NonexistentEntityException("The exame with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Exame exame;
            try {
                exame = em.getReference(Exame.class, id);
                exame.getIdExame();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The exame with id " + id + " no longer exists.", enfe);
            }
            Alunos alunosIdAluno = exame.getAlunosIdAluno();
            if (alunosIdAluno != null) {
                alunosIdAluno.getExameList().remove(exame);
                alunosIdAluno = em.merge(alunosIdAluno);
            }
            em.remove(exame);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Exame> findExameEntities() {
        return findExameEntities(true, -1, -1);
    }

    public List<Exame> findExameEntities(int maxResults, int firstResult) {
        return findExameEntities(false, maxResults, firstResult);
    }

    private List<Exame> findExameEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Exame.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Exame findExame(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Exame.class, id);
        } finally {
            em.close();
        }
    }

    public int getExameCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Exame> rt = cq.from(Exame.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
