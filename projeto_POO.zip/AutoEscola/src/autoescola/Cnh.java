/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autoescola;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author gasin
 */
@Entity
@Table(name = "cnh")
@NamedQueries({
    @NamedQuery(name = "Cnh.findAll", query = "SELECT c FROM Cnh c"),
    @NamedQuery(name = "Cnh.findByIdCnh", query = "SELECT c FROM Cnh c WHERE c.idCnh = :idCnh"),
    @NamedQuery(name = "Cnh.findByTipoCnh", query = "SELECT c FROM Cnh c WHERE c.tipoCnh = :tipoCnh"),
    @NamedQuery(name = "Cnh.findByDataregistroCnh", query = "SELECT c FROM Cnh c WHERE c.dataregistroCnh = :dataregistroCnh")})
public class Cnh implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_cnh")
    private Integer idCnh;
    @Basic(optional = false)
    @Column(name = "tipo_cnh")
    private String tipoCnh;
    @Basic(optional = false)
    @Column(name = "dataregistro_cnh")
    @Temporal(TemporalType.DATE)
    private Date dataregistroCnh;
    @JoinColumn(name = "alunos_id_aluno", referencedColumnName = "id_aluno")
    @ManyToOne(optional = false)
    @JoinColumn(name = "alunos_id_aluno", nullable = false)
    private Alunos alunosIdAluno;

    public Cnh() {
    }

    public Cnh(Integer idCnh) {
        this.idCnh = idCnh;
    }

    public Cnh(String tipoCnh, Date dataregistroCnh) {
        this.tipoCnh = tipoCnh;
        this.dataregistroCnh = dataregistroCnh;
    }

    public Integer getIdCnh() {
        return idCnh;
    }

    public void setIdCnh(Integer idCnh) {
        this.idCnh = idCnh;
    }

    public String getTipoCnh() {
        return tipoCnh;
    }

    public void setTipoCnh(String tipoCnh) {
        this.tipoCnh = tipoCnh;
    }

    public Date getDataregistroCnh() {
        return dataregistroCnh;
    }

    public void setDataregistroCnh(Date dataregistroCnh) {
        this.dataregistroCnh = dataregistroCnh;
    }

    public Alunos getAlunosIdAluno() {
        return alunosIdAluno;
    }

    public void setAlunosIdAluno(Alunos alunosIdAluno) {
        this.alunosIdAluno = alunosIdAluno;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCnh != null ? idCnh.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cnh)) {
            return false;
        }
        Cnh other = (Cnh) object;
        if ((this.idCnh == null && other.idCnh != null) || (this.idCnh != null && !this.idCnh.equals(other.idCnh))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "autoescola.Cnh[ idCnh=" + idCnh + " ]";
    }
    
}
