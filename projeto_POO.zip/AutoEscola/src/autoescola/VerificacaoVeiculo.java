/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autoescola;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author gasin
 */
@Entity
@Table(name = "verificacao_veiculo")
@NamedQueries({
    @NamedQuery(name = "VerificacaoVeiculo.findAll", query = "SELECT v FROM VerificacaoVeiculo v"),
    @NamedQuery(name = "VerificacaoVeiculo.findByIdVerificacao", query = "SELECT v FROM VerificacaoVeiculo v WHERE v.idVerificacao = :idVerificacao"),
    @NamedQuery(name = "VerificacaoVeiculo.findBySolucionadoVerificacao", query = "SELECT v FROM VerificacaoVeiculo v WHERE v.solucionadoVerificacao = :solucionadoVerificacao"),
    @NamedQuery(name = "VerificacaoVeiculo.findByDescVerificacao", query = "SELECT v FROM VerificacaoVeiculo v WHERE v.descVerificacao = :descVerificacao"),
    @NamedQuery(name = "VerificacaoVeiculo.findByTipoVerificacao", query = "SELECT v FROM VerificacaoVeiculo v WHERE v.tipoVerificacao = :tipoVerificacao")})
public class VerificacaoVeiculo implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_verificacao")
    private Integer idVerificacao;
    @Basic(optional = false)
    @Column(name = "solucionado_verificacao")
    private short solucionadoVerificacao;
    @Basic(optional = false)
    @Column(name = "desc_verificacao")
    private String descVerificacao;
    @Basic(optional = false)
    @Column(name = "tipo_verificacao")
    private String tipoVerificacao;
    @JoinColumn(name = "instrutor_id_instrutor", referencedColumnName = "id_instrutor")
    @ManyToOne(optional = false)
    private Instrutor instrutorIdInstrutor;
    @JoinColumn(name = "veiculo_id_veiculo", referencedColumnName = "id_veiculo")
    @ManyToOne(optional = false)
    private Veiculo veiculoIdVeiculo;

    public VerificacaoVeiculo() {
    }

    public VerificacaoVeiculo(Integer idVerificacao) {
        this.idVerificacao = idVerificacao;
    }

    public VerificacaoVeiculo(Integer idVerificacao, short solucionadoVerificacao, String descVerificacao, String tipoVerificacao) {
        this.idVerificacao = idVerificacao;
        this.solucionadoVerificacao = solucionadoVerificacao;
        this.descVerificacao = descVerificacao;
        this.tipoVerificacao = tipoVerificacao;
    }

    public Integer getIdVerificacao() {
        return idVerificacao;
    }

    public void setIdVerificacao(Integer idVerificacao) {
        this.idVerificacao = idVerificacao;
    }

    public short getSolucionadoVerificacao() {
        return solucionadoVerificacao;
    }

    public void setSolucionadoVerificacao(short solucionadoVerificacao) {
        this.solucionadoVerificacao = solucionadoVerificacao;
    }

    public String getDescVerificacao() {
        return descVerificacao;
    }

    public void setDescVerificacao(String descVerificacao) {
        this.descVerificacao = descVerificacao;
    }

    public String getTipoVerificacao() {
        return tipoVerificacao;
    }

    public void setTipoVerificacao(String tipoVerificacao) {
        this.tipoVerificacao = tipoVerificacao;
    }

    public Instrutor getInstrutorIdInstrutor() {
        return instrutorIdInstrutor;
    }

    public void setInstrutorIdInstrutor(Instrutor instrutorIdInstrutor) {
        this.instrutorIdInstrutor = instrutorIdInstrutor;
    }

    public Veiculo getVeiculoIdVeiculo() {
        return veiculoIdVeiculo;
    }

    public void setVeiculoIdVeiculo(Veiculo veiculoIdVeiculo) {
        this.veiculoIdVeiculo = veiculoIdVeiculo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idVerificacao != null ? idVerificacao.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof VerificacaoVeiculo)) {
            return false;
        }
        VerificacaoVeiculo other = (VerificacaoVeiculo) object;
        if ((this.idVerificacao == null && other.idVerificacao != null) || (this.idVerificacao != null && !this.idVerificacao.equals(other.idVerificacao))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "autoescola.VerificacaoVeiculo[ idVerificacao=" + idVerificacao + " ]";
    }
    
}
