/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autoescola;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author gasin
 */
@Entity
@Table(name = "avaliacao")
@NamedQueries({
    @NamedQuery(name = "Avaliacao.findAll", query = "SELECT a FROM Avaliacao a"),
    @NamedQuery(name = "Avaliacao.findByIdAvaliacao", query = "SELECT a FROM Avaliacao a WHERE a.idAvaliacao = :idAvaliacao"),
    @NamedQuery(name = "Avaliacao.findByNotaAvaliacao", query = "SELECT a FROM Avaliacao a WHERE a.notaAvaliacao = :notaAvaliacao"),
    @NamedQuery(name = "Avaliacao.findByTipoAvaliacao", query = "SELECT a FROM Avaliacao a WHERE a.tipoAvaliacao = :tipoAvaliacao"),
    @NamedQuery(name = "Avaliacao.findByDescAvaliacao", query = "SELECT a FROM Avaliacao a WHERE a.descAvaliacao = :descAvaliacao")})
public class Avaliacao implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_avaliacao")
    private Integer idAvaliacao;
    @Basic(optional = false)
    @Column(name = "nota_avaliacao")
    private int notaAvaliacao;
    @Basic(optional = false)
    @Column(name = "tipo_avaliacao")
    private String tipoAvaliacao;
    @Column(name = "desc_avaliacao")
    private String descAvaliacao;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "avaliacaoIdAvaliacao")
    private List<AgendamentoAula> agendamentoAulaList;

    public Avaliacao() {
    }

    public Avaliacao(Integer idAvaliacao) {
        this.idAvaliacao = idAvaliacao;
    }

    public Avaliacao(int notaAvaliacao, String tipoAvaliacao) {
        this.notaAvaliacao = notaAvaliacao;
        this.tipoAvaliacao = tipoAvaliacao;
    }

    public Integer getIdAvaliacao() {
        return idAvaliacao;
    }

    public void setIdAvaliacao(Integer idAvaliacao) {
        this.idAvaliacao = idAvaliacao;
    }

    public int getNotaAvaliacao() {
        return notaAvaliacao;
    }

    public void setNotaAvaliacao(int notaAvaliacao) {
        this.notaAvaliacao = notaAvaliacao;
    }

    public String getTipoAvaliacao() {
        return tipoAvaliacao;
    }

    public void setTipoAvaliacao(String tipoAvaliacao) {
        this.tipoAvaliacao = tipoAvaliacao;
    }

    public String getDescAvaliacao() {
        return descAvaliacao;
    }

    public void setDescAvaliacao(String descAvaliacao) {
        this.descAvaliacao = descAvaliacao;
    }

    public List<AgendamentoAula> getAgendamentoAulaList() {
        return agendamentoAulaList;
    }

    public void setAgendamentoAulaList(List<AgendamentoAula> agendamentoAulaList) {
        this.agendamentoAulaList = agendamentoAulaList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idAvaliacao != null ? idAvaliacao.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Avaliacao)) {
            return false;
        }
        Avaliacao other = (Avaliacao) object;
        if ((this.idAvaliacao == null && other.idAvaliacao != null) || (this.idAvaliacao != null && !this.idAvaliacao.equals(other.idAvaliacao))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "autoescola.Avaliacao[ idAvaliacao=" + idAvaliacao + " ]";
    }
    
}
