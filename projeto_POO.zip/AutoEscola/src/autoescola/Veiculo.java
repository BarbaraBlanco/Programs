/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autoescola;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author gasin
 */
@Entity
@Table(name = "veiculo")
@NamedQueries({
    @NamedQuery(name = "Veiculo.findAll", query = "SELECT v FROM Veiculo v"),
    @NamedQuery(name = "Veiculo.findByIdVeiculo", query = "SELECT v FROM Veiculo v WHERE v.idVeiculo = :idVeiculo"),
    @NamedQuery(name = "Veiculo.findByTipoVeiculo", query = "SELECT v FROM Veiculo v WHERE v.tipoVeiculo = :tipoVeiculo"),
    @NamedQuery(name = "Veiculo.findByMarcaVeiculo", query = "SELECT v FROM Veiculo v WHERE v.marcaVeiculo = :marcaVeiculo"),
    @NamedQuery(name = "Veiculo.findByPlacaVeiculo", query = "SELECT v FROM Veiculo v WHERE v.placaVeiculo = :placaVeiculo"),
    @NamedQuery(name = "Veiculo.findByVencimentoDocumento", query = "SELECT v FROM Veiculo v WHERE v.vencimentoDocumento = :vencimentoDocumento")})
public class Veiculo implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_veiculo")
    private Integer idVeiculo;
    @Basic(optional = false)
    @Column(name = "tipo_veiculo")
    private String tipoVeiculo;
    @Basic(optional = false)
    @Column(name = "marca_veiculo")
    private String marcaVeiculo;
    @Basic(optional = false)
    @Column(name = "placa_veiculo")
    private String placaVeiculo;
    @Basic(optional = false)
    @Column(name = "vencimento_documento")
    @Temporal(TemporalType.DATE)
    private Date vencimentoDocumento;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "veiculoIdVeiculo")
    private List<VerificacaoVeiculo> verificacaoVeiculoList;

    public Veiculo() {
    }

    public Veiculo(Integer idVeiculo) {
        this.idVeiculo = idVeiculo;
    }

    public Veiculo(Integer idVeiculo, String tipoVeiculo, String marcaVeiculo, String placaVeiculo, Date vencimentoDocumento) {
        this.idVeiculo = idVeiculo;
        this.tipoVeiculo = tipoVeiculo;
        this.marcaVeiculo = marcaVeiculo;
        this.placaVeiculo = placaVeiculo;
        this.vencimentoDocumento = vencimentoDocumento;
    }

    public Integer getIdVeiculo() {
        return idVeiculo;
    }

    public void setIdVeiculo(Integer idVeiculo) {
        this.idVeiculo = idVeiculo;
    }

    public String getTipoVeiculo() {
        return tipoVeiculo;
    }

    public void setTipoVeiculo(String tipoVeiculo) {
        this.tipoVeiculo = tipoVeiculo;
    }

    public String getMarcaVeiculo() {
        return marcaVeiculo;
    }

    public void setMarcaVeiculo(String marcaVeiculo) {
        this.marcaVeiculo = marcaVeiculo;
    }

    public String getPlacaVeiculo() {
        return placaVeiculo;
    }

    public void setPlacaVeiculo(String placaVeiculo) {
        this.placaVeiculo = placaVeiculo;
    }

    public Date getVencimentoDocumento() {
        return vencimentoDocumento;
    }

    public void setVencimentoDocumento(Date vencimentoDocumento) {
        this.vencimentoDocumento = vencimentoDocumento;
    }

    public List<VerificacaoVeiculo> getVerificacaoVeiculoList() {
        return verificacaoVeiculoList;
    }

    public void setVerificacaoVeiculoList(List<VerificacaoVeiculo> verificacaoVeiculoList) {
        this.verificacaoVeiculoList = verificacaoVeiculoList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idVeiculo != null ? idVeiculo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Veiculo)) {
            return false;
        }
        Veiculo other = (Veiculo) object;
        if ((this.idVeiculo == null && other.idVeiculo != null) || (this.idVeiculo != null && !this.idVeiculo.equals(other.idVeiculo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "autoescola.Veiculo[ idVeiculo=" + idVeiculo + " ]";
    }
    
}
