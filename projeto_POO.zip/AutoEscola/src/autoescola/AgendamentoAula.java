/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autoescola;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author gasin
 */
@Entity
@Table(name = "agendamento_aula")
@NamedQueries({
    @NamedQuery(name = "AgendamentoAula.findAll", query = "SELECT a FROM AgendamentoAula a"),
    @NamedQuery(name = "AgendamentoAula.findByIdAgendamento", query = "SELECT a FROM AgendamentoAula a WHERE a.idAgendamento = :idAgendamento"),
    @NamedQuery(name = "AgendamentoAula.findByDatetime", query = "SELECT a FROM AgendamentoAula a WHERE a.datetime = :datetime"),
    @NamedQuery(name = "AgendamentoAula.findBySituacaoAgendamento", query = "SELECT a FROM AgendamentoAula a WHERE a.situacaoAgendamento = :situacaoAgendamento")})
public class AgendamentoAula implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_agendamento")
    private Integer idAgendamento;
    @Basic(optional = false)
    @Column(name = "datetime")
    @Temporal(TemporalType.DATE)
    private Date datetime;
    @Basic(optional = false)
    @Column(name = "situacao_agendamento")
    private String situacaoAgendamento;
    @JoinColumn(name = "alunos_id_aluno", referencedColumnName = "id_aluno")
    @ManyToOne(optional = false)
    private Alunos alunosIdAluno;
    @JoinColumn(name = "avaliacao_id_avaliacao", referencedColumnName = "id_avaliacao")
    @ManyToOne(optional = false)
    private Avaliacao avaliacaoIdAvaliacao;
    @JoinColumn(name = "instrutor_id_instrutor", referencedColumnName = "id_instrutor")
    @ManyToOne(optional = false)
    private Instrutor instrutorIdInstrutor;

    public AgendamentoAula() {
    }

    public AgendamentoAula(Integer idAgendamento) {
        this.idAgendamento = idAgendamento;
    }

    public AgendamentoAula(Date datetime, String situacaoAgendamento, Instrutor instrutor, Alunos alunos, Avaliacao avaliacaoId) {
        this.instrutorIdInstrutor = instrutor;
        this.alunosIdAluno = alunos;
        this.avaliacaoIdAvaliacao = avaliacaoId;
        this.datetime = datetime;
        this.situacaoAgendamento = situacaoAgendamento;
    }

    public Integer getIdAgendamento() {
        return idAgendamento;
    }

    public void setIdAgendamento(Integer idAgendamento) {
        this.idAgendamento = idAgendamento;
    }

    public Date getDatetime() {
        return datetime;
    }

    public void setDatetime(Date datetime) {
        this.datetime = datetime;
    }

    public String getSituacaoAgendamento() {
        return situacaoAgendamento;
    }

    public void setSituacaoAgendamento(String situacaoAgendamento) {
        this.situacaoAgendamento = situacaoAgendamento;
    }

    public Alunos getAlunosIdAluno() {
        return alunosIdAluno;
    }

    public void setAlunosIdAluno(Alunos alunosIdAluno) {
        this.alunosIdAluno = alunosIdAluno;
    }

    public Avaliacao getAvaliacaoIdAvaliacao() {
        return avaliacaoIdAvaliacao;
    }

    public void setAvaliacaoIdAvaliacao(Avaliacao avaliacaoIdAvaliacao) {
        this.avaliacaoIdAvaliacao = avaliacaoIdAvaliacao;
    }

    public Instrutor getInstrutorIdInstrutor() {
        return instrutorIdInstrutor;
    }

    public void setInstrutorIdInstrutor(Instrutor instrutorIdInstrutor) {
        this.instrutorIdInstrutor = instrutorIdInstrutor;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idAgendamento != null ? idAgendamento.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AgendamentoAula)) {
            return false;
        }
        AgendamentoAula other = (AgendamentoAula) object;
        if ((this.idAgendamento == null && other.idAgendamento != null) || (this.idAgendamento != null && !this.idAgendamento.equals(other.idAgendamento))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "autoescola.AgendamentoAula[ idAgendamento=" + idAgendamento + " ]";
    }
    
}
