/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autoescola;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author gasin
 */
@Entity
@Table(name = "alunos")
@NamedQueries({
    @NamedQuery(name = "Alunos.findAll", query = "SELECT a FROM Alunos a"),
    @NamedQuery(name = "Alunos.findByIdAluno", query = "SELECT a FROM Alunos a WHERE a.idAluno = :idAluno"),
    @NamedQuery(name = "Alunos.findByNascimentoAluno", query = "SELECT a FROM Alunos a WHERE a.nascimentoAluno = :nascimentoAluno"),
    @NamedQuery(name = "Alunos.findByEmailAluno", query = "SELECT a FROM Alunos a WHERE a.emailAluno = :emailAluno"),
    @NamedQuery(name = "Alunos.findByCpfAluno", query = "SELECT a FROM Alunos a WHERE a.cpfAluno = :cpfAluno"),
    @NamedQuery(name = "Alunos.findBySenhaAluno", query = "SELECT a FROM Alunos a WHERE a.senhaAluno = :senhaAluno"),
    @NamedQuery(name = "Alunos.findByDataregistroAluno", query = "SELECT a FROM Alunos a WHERE a.dataregistroAluno = :dataregistroAluno"),
    @NamedQuery(name = "Alunos.findByCelular", query = "SELECT a FROM Alunos a WHERE a.celular = :celular"),
    @NamedQuery(name = "Alunos.findByBairro", query = "SELECT a FROM Alunos a WHERE a.bairro = :bairro"),
    @NamedQuery(name = "Alunos.findByRua", query = "SELECT a FROM Alunos a WHERE a.rua = :rua"),
    @NamedQuery(name = "Alunos.findBySnomeAluno", query = "SELECT a FROM Alunos a WHERE a.snomeAluno = :snomeAluno"),
    @NamedQuery(name = "Alunos.findByPnomeAluno", query = "SELECT a FROM Alunos a WHERE a.pnomeAluno = :pnomeAluno")})
public class Alunos implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_aluno")
    private Integer idAluno;
    @Column(name = "nascimento_aluno")
    @Temporal(TemporalType.DATE)
    private Date nascimentoAluno;
    @Basic(optional = false)
    @Column(name = "email_aluno")
    private String emailAluno;
    @Basic(optional = false)
    @Column(name = "cpf_aluno")
    private String cpfAluno;
    @Basic(optional = false)
    @Column(name = "senha_aluno")
    private String senhaAluno;
    @Basic(optional = false)
    @Column(name = "dataregistro_aluno")
    @Temporal(TemporalType.DATE)
    private Date dataregistroAluno;
    @Basic(optional = false)
    @Column(name = "celular")
    private String celular;
    @Column(name = "bairro")
    private String bairro;
    @Column(name = "rua")
    private String rua;
    @Basic(optional = false)
    @Column(name = "snome_aluno")
    private String snomeAluno;
    @Basic(optional = false)
    @Column(name = "pnome_aluno")
    private String pnomeAluno;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "alunosIdAluno")
    private List<AgendamentoAula> agendamentoAulaList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "alunosIdAluno")
    private List<Exame> exameList;
    @OneToMany(mappedBy = "alunosIdAluno", cascade = CascadeType.PERSIST, orphanRemoval = true)
    private List<Cnh> cnhList;

    public Alunos() {
    }

    public Alunos(Integer idAluno) {
        this.idAluno = idAluno;
    }

    public Alunos(String emailAluno, String cpfAluno, String senhaAluno, Date dataregistroAluno, String celular, String snomeAluno, String pnomeAluno, Date nascimentoAluno, String rua, String bairro) {
   
        this.emailAluno = emailAluno;
        this.cpfAluno = cpfAluno;
        this.senhaAluno = senhaAluno;
        this.dataregistroAluno = dataregistroAluno;
        this.celular = celular;
        this.nascimentoAluno = nascimentoAluno;
        this.snomeAluno = snomeAluno;
        this.pnomeAluno = pnomeAluno;
        this.rua = rua;
        this.bairro = bairro;
    }

    public Integer getIdAluno() {
        return idAluno;
    }

    public void setIdAluno(Integer idAluno) {
        this.idAluno = idAluno;
    }

    public Date getNascimentoAluno() {
        return nascimentoAluno;
    }

    public void setNascimentoAluno(Date nascimentoAluno) {
        this.nascimentoAluno = nascimentoAluno;
    }

    public String getEmailAluno() {
        return emailAluno;
    }

    public void setEmailAluno(String emailAluno) {
        this.emailAluno = emailAluno;
    }

    public String getCpfAluno() {
        return cpfAluno;
    }

    public void setCpfAluno(String cpfAluno) {
        this.cpfAluno = cpfAluno;
    }

    public String getSenhaAluno() {
        return senhaAluno;
    }

    public void setSenhaAluno(String senhaAluno) {
        this.senhaAluno = senhaAluno;
    }

    public Date getDataregistroAluno() {
        return dataregistroAluno;
    }

    public void setDataregistroAluno(Date dataregistroAluno) {
        this.dataregistroAluno = dataregistroAluno;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public String getSnomeAluno() {
        return snomeAluno;
    }

    public void setSnomeAluno(String snomeAluno) {
        this.snomeAluno = snomeAluno;
    }

    public String getPnomeAluno() {
        return pnomeAluno;
    }

    public void setPnomeAluno(String pnomeAluno) {
        this.pnomeAluno = pnomeAluno;
    }

    public List<AgendamentoAula> getAgendamentoAulaList() {
        return agendamentoAulaList;
    }

    public void setAgendamentoAulaList(List<AgendamentoAula> agendamentoAulaList) {
        this.agendamentoAulaList = agendamentoAulaList;
    }

    public List<Exame> getExameList() {
        return exameList;
    }

    public void setExameList(List<Exame> exameList) {
        this.exameList = exameList;
    }

    public List<Cnh> getCnhList() {
        return cnhList;
    }

    public void setCnhList(List<Cnh> cnhList) {
        this.cnhList = cnhList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idAluno != null ? idAluno.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Alunos)) {
            return false;
        }
        Alunos other = (Alunos) object;
        if ((this.idAluno == null && other.idAluno != null) || (this.idAluno != null && !this.idAluno.equals(other.idAluno))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "autoescola.Alunos[ idAluno=" + idAluno + " ]";
    }
    
}
