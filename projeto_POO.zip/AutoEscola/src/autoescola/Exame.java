/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autoescola;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author gasin
 */
@Entity
@Table(name = "exame")
@NamedQueries({
    @NamedQuery(name = "Exame.findAll", query = "SELECT e FROM Exame e"),
    @NamedQuery(name = "Exame.findByIdExame", query = "SELECT e FROM Exame e WHERE e.idExame = :idExame"),
    @NamedQuery(name = "Exame.findByDataExame", query = "SELECT e FROM Exame e WHERE e.dataExame = :dataExame"),
    @NamedQuery(name = "Exame.findByResultadoExame", query = "SELECT e FROM Exame e WHERE e.resultadoExame = :resultadoExame")})
public class Exame implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_exame")
    private Integer idExame;
    @Basic(optional = false)
    @Column(name = "data_exame")
    @Temporal(TemporalType.DATE)
    private Date dataExame;
    @Basic(optional = false)
    @Column(name = "resultado_exame")
    private short resultadoExame;
    @JoinColumn(name = "alunos_id_aluno", referencedColumnName = "id_aluno")
    @ManyToOne(optional = false)
    private Alunos alunosIdAluno;

    public Exame() {
    }
    
    public Exame(Integer idExame) {
        this.idExame = idExame;
    }

    public Exame(Date dataExame, short resultadoExame, Alunos alunoId) {
        this.dataExame = dataExame;
        this.resultadoExame = resultadoExame;
        this.alunosIdAluno = alunoId;
    }

    public Integer getIdExame() {
        return idExame;
    }

    public void setIdExame(Integer idExame) {
        this.idExame = idExame;
    }

    public Date getDataExame() {
        return dataExame;
    }

    public void setDataExame(Date dataExame) {
        this.dataExame = dataExame;
    }

    public short getResultadoExame() {
        return resultadoExame;
    }

    public void setResultadoExame(short resultadoExame) {
        this.resultadoExame = resultadoExame;
    }

    public Alunos getAlunosIdAluno() {
        return alunosIdAluno;
    }

    public void setAlunosIdAluno(Alunos alunosIdAluno) {
        this.alunosIdAluno = alunosIdAluno;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idExame != null ? idExame.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Exame)) {
            return false;
        }
        Exame other = (Exame) object;
        if ((this.idExame == null && other.idExame != null) || (this.idExame != null && !this.idExame.equals(other.idExame))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "autoescola.Exame[ idExame=" + idExame + " ]";
    }
    
}
